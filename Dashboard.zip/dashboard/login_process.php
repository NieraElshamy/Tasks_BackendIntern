<?php
session_start();
include("config/dp.php");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.php?error=Invalid+Request");
    exit;
}

$userName = isset($_POST['username']) ? trim($_POST['username']) : '';
$pass     = isset($_POST['pass']) ? trim($_POST['pass']) : '';

if ($userName === '' || $pass === '') {
    header("Location: login.php?error=Missing+Credentials");
    exit;
}

$sql = "SELECT id, name, username, password FROM users WHERE username = ? LIMIT 1";
$stnt = $conn->prepare($sql);
if (!$stnt) {
    header("Location: login.php?error=Server+Error");
    exit;
}

$stnt->bind_param("s", $userName);
$stnt->execute();
$result = $stnt->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($pass, $user["password"])) {
    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id'       => $user['id'],
        'username' => $user['username'], 
        'name' => $user['name']
    ];
    header("Location: index.php");
    exit;
}
else{
header("Location: login.php?error=Invalid+Username+Or+Password");
}

exit;
