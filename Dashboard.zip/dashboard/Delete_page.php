<?php
session_start();
require_once "config/dp.php";

if (!isset($_SESSION['user'])) { 
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { 
    header("Location: list.php?error=bad+request");
    exit;
}

$productName = trim($_POST['product_name'] ?? '');
if ($productName === '') {
    header("Location: list.php?error=no+product");
    exit;
}


$sqlLastOrder = "
    SELECT id 
    FROM orders 
    WHERE product_name = ? 
    ORDER BY id DESC 
    LIMIT 1
";
$stmt = $conn->prepare($sqlLastOrder);
$stmt->bind_param("s", $productName);
$stmt->execute();
$res = $stmt->get_result();
$lastOrder = $res->fetch_assoc();

if (!$lastOrder) {
    header("Location: list.php?error=no+orders+for+this+product");
    exit;
}

$lastOrderId = (int)$lastOrder['id'];

$del = $conn->prepare("DELETE FROM orders WHERE id = ?");
$del->bind_param("i", $lastOrderId);
$del->execute();

if ($del->affected_rows > 0) {
    header("Location: list.php?success=last+order+removed");
} else {
    header("Location: list.php?error=nothing+deleted");
}
exit;
?>
