<?php
include("config/dp.php");

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

if (!empty($_SESSION['flash_error'])) {
    echo '<div class="alert alert-danger">'.htmlspecialchars($_SESSION['flash_error']).'</div>';
    unset($_SESSION['flash_error']);
}


$currentUserId = (int)$_SESSION['user']['id'];


$sqlProducts = "
    SELECT 
        product_name,
        MIN(order_date) AS first_order_date,
        MAX(order_date) AS last_order_date,
        SUM(quantity)   AS total_qty
    FROM orders
    GROUP BY product_name
    ORDER BY last_order_date DESC
";
$resProducts = $conn->query($sqlProducts);
$products = [];
if ($resProducts) {
    while ($row = $resProducts->fetch_assoc()) {
        $products[] = $row;
    }
}

function getProductBuyers(mysqli $conn, string $productName): array {
    $sql = "
        SELECT u.id, u.name, u.username, SUM(o.quantity) AS qty
        FROM orders o
        JOIN users u ON u.id = o.user_id
        WHERE o.product_name = ?
        GROUP BY u.id, u.name, u.username
        ORDER BY u.name ASC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $productName);
    $stmt->execute();
    $res = $stmt->get_result();
    $buyers = [];
    while ($r = $res->fetch_assoc()) { $buyers[] = $r; }
    return $buyers;
}

function user_avatar_src(array $buyer): string {
    return "dist/img/avatar.png";
}

function fmt_dt(?string $dt): string {
    if (!$dt) return '—';
    return date('Y-m-d', strtotime($dt));
}
?>
