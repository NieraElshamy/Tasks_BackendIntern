<?php

if (empty($_SESSION['user'])) {
    $_SESSION['flash_error'] = "SIGN IN FIRST";
    header("Location: login.php");
    exit;
}

$allowedPage = $_SESSION['allowed_page'] ?? 'login.php';
$currentPage = basename($_SERVER['PHP_SELF']);

if ($currentPage !== $allowedPage) {
    $_SESSION['flash_error'] = "This page not allowed to you";
    header("Location: $allowedPage");
    exit;
}
