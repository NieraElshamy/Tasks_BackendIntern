<?php
session_start();
require_once "config/dp.php";

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: products.php?error=Bad+Request");
    exit;
}

$userId = $_SESSION['user']['id'];
$name   = isset($_POST['product_name'])  ? trim($_POST['product_name'])  : '';
$price  = isset($_POST['product_price']) ? trim($_POST['product_price']) : '';
$qty    = isset($_POST['quantity'])      ? (int)$_POST['quantity']       : 1;

if ($name === '' || !is_numeric($price) || $price <= 0 || $qty <= 0) {
    header("Location: products.php?error=Bad+Product+Data");
    exit;
}

$sql = "INSERT INTO orders (user_id, product_name, price, quantity, order_date)
        VALUES (?, ?, ?, ?, NOW())";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isdi", $userId, $name, $price, $qty);
$stmt->execute();

if ($stmt->affected_rows === 1) {
    header("Location: profile.php?success=Product+Saved");
    exit;
} else {
    header("Location: e-commerce.php?error=Save+Failed");
    exit;
}
