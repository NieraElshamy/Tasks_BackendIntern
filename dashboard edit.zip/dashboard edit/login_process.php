<?php
session_start();
include("config/dp.php");

$userName = trim($_POST['username'] ?? '');
$pass     = $_POST['pass'] ?? '';
$role     = isset($_POST['role']) ? (int)$_POST['role'] : -1;

if ($userName === '' || $pass === '' || $role === -1) {
    header("Location: login.php?error=Missing+Credentials");
    exit;
}


$sql = "SELECT id, username, password FROM users WHERE username = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $userName);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 1) {
    $user = $res->fetch_assoc();

    
    if (!password_verify($pass, $user['password'])) {
        header("Location: login.php?error=Invalid+Password");
        exit;
    }


    $_SESSION['user'] = [
        'id'       => $user['id'],
        'username' => $user['username'],
        'role'     => $role 
    ];

  
    switch ($role) {
        case 1:
            $_SESSION['allowed_page'] = 'list.php';      // Admin
            header("Location: list.php");
            break;
        case 0:
            $_SESSION['allowed_page'] = 'profile.php';   // User
            header("Location: profile.php");
            break;
        case 2:
            $_SESSION['allowed_page'] = 'e-commerce.php';// Viewer
            header("Location: e-commerce.php");
            break;
        default:
            header("Location: login.php?error=Invalid+Role");
            break;
    }
    exit;
} else {
    header("Location: login.php?error=Invalid+Credentials");
    exit;
}
