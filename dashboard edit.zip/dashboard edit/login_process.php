<?php
session_start();
include("config/dp.php");

$userName = trim($_POST['username'] ?? '');
$pass     = $_POST['pass'] ?? '';

if ($userName === '' || $pass === '') {
    header("Location: login.php?error=Missing+Credentials");
    exit;
}

$sql = "SELECT u.id, u.username, u.password, u.Rule_id, r.name AS role_name
        FROM users u
        JOIN rules r ON u.Rule_id = r.id
        WHERE u.username = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $userName);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 1) {
    $user = $res->fetch_assoc();

   
    if (!password_verify($pass, $user['password'])) {
        header("Location: login.php?error=Invalid+Password");
        exit;
    }

   
    $_SESSION['user'] = [
        'id'        => $user['id'],
        'username'  => $user['username'],
        'role'      => $user['Rule_id'],
        'role_name' => $user['role_name']
    ];

    switch ($user['Rule_id']) {
        case 1: // Admin
            $_SESSION['allowed_page'] = 'list.php';
            header("Location: list.php");
            break;
        case 0: // User
            $_SESSION['allowed_page'] = 'profile.php';
            header("Location: profile.php");
            break;
        case 2: // Viewer
            $_SESSION['allowed_page'] = 'e-commerce.php';
            header("Location: e-commerce.php");
            break;
        default:
            header("Location: login.php?error=Invalid+Role");
            break;
    }
    exit;
} else {
    header("Location: login.php?error=Invalid+Credentials");
    exit;
}
